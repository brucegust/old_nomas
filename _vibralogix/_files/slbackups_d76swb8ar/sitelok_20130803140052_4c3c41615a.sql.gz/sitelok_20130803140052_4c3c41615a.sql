DROP TABLE IF EXISTS sitelok;


CREATE TABLE `sitelok` (
  `Selected` varchar(3) NOT NULL DEFAULT '',
  `Created` varchar(6) NOT NULL DEFAULT '',
  `Username` varchar(50) NOT NULL,
  `Passphrase` varchar(50) NOT NULL DEFAULT '',
  `Enabled` varchar(3) NOT NULL DEFAULT '',
  `Name` varchar(50) NOT NULL DEFAULT '',
  `Email` varchar(50) NOT NULL DEFAULT '',
  `Usergroups` varchar(255) NOT NULL DEFAULT '',
  `Custom1` varchar(255) NOT NULL DEFAULT '',
  `Custom2` varchar(255) NOT NULL DEFAULT '',
  `Custom3` varchar(255) NOT NULL DEFAULT '',
  `Custom4` varchar(255) NOT NULL DEFAULT '',
  `Custom5` varchar(255) NOT NULL DEFAULT '',
  `Custom6` varchar(255) NOT NULL DEFAULT '',
  `Custom7` varchar(255) NOT NULL DEFAULT '',
  `Custom8` varchar(255) NOT NULL DEFAULT '',
  `Custom9` varchar(255) NOT NULL DEFAULT '',
  `Custom10` varchar(255) NOT NULL DEFAULT '',
  `Custom11` varchar(255) NOT NULL DEFAULT '',
  `Custom12` varchar(255) NOT NULL DEFAULT '',
  `Custom13` varchar(255) NOT NULL DEFAULT '',
  `Custom14` varchar(255) NOT NULL DEFAULT '',
  `Custom15` varchar(255) NOT NULL DEFAULT '',
  `Custom16` varchar(255) NOT NULL DEFAULT '',
  `Custom17` varchar(255) NOT NULL DEFAULT '',
  `Custom18` varchar(255) NOT NULL DEFAULT '',
  `Custom19` varchar(255) NOT NULL DEFAULT '',
  `Custom20` varchar(255) NOT NULL DEFAULT '',
  `Custom21` varchar(255) NOT NULL DEFAULT '',
  `Custom22` varchar(255) NOT NULL DEFAULT '',
  `Custom23` varchar(255) NOT NULL DEFAULT '',
  `Custom24` varchar(255) NOT NULL DEFAULT '',
  `Custom25` varchar(255) NOT NULL DEFAULT '',
  `Custom26` varchar(255) NOT NULL DEFAULT '',
  `Custom27` varchar(255) NOT NULL DEFAULT '',
  `Custom28` varchar(255) NOT NULL DEFAULT '',
  `Custom29` varchar(255) NOT NULL DEFAULT '',
  `Custom30` varchar(255) NOT NULL DEFAULT '',
  `Custom31` varchar(255) NOT NULL DEFAULT '',
  `Custom32` varchar(255) NOT NULL DEFAULT '',
  `Custom33` varchar(255) NOT NULL DEFAULT '',
  `Custom34` varchar(255) NOT NULL DEFAULT '',
  `Custom35` varchar(255) NOT NULL DEFAULT '',
  `Custom36` varchar(255) NOT NULL DEFAULT '',
  `Custom37` varchar(255) NOT NULL DEFAULT '',
  `Custom38` varchar(255) NOT NULL DEFAULT '',
  `Custom39` varchar(255) NOT NULL DEFAULT '',
  `Custom40` varchar(255) NOT NULL DEFAULT '',
  `Custom41` varchar(255) NOT NULL DEFAULT '',
  `Custom42` varchar(255) NOT NULL DEFAULT '',
  `Custom43` varchar(255) NOT NULL DEFAULT '',
  `Custom44` varchar(255) NOT NULL DEFAULT '',
  `Custom45` varchar(255) NOT NULL DEFAULT '',
  `Custom46` varchar(255) NOT NULL DEFAULT '',
  `Custom47` varchar(255) NOT NULL DEFAULT '',
  `Custom48` varchar(255) NOT NULL DEFAULT '',
  `Custom49` varchar(255) NOT NULL DEFAULT '',
  `Custom50` varchar(255) NOT NULL DEFAULT '',
  `Session` varchar(255) NOT NULL DEFAULT '',
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Username` (`Username`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;


INSERT INTO sitelok VALUES('No','010101','poeb','pa55word','Yes','Peter Bekker','peterbe@verizon.net','ADMIN^ALL^FORUM','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','fe00beebb7eedbff033cb192851d90439e68dd4e','1');
INSERT INTO sitelok VALUES('No','130714','mmpalmer','skylar','Yes','Marjorie Meyer Palmer','marjorie@successfulfeeding.com','ADMIN^ALL^FORUM^NOMAS','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','2');



DROP TABLE IF EXISTS slconfig;


CREATE TABLE `slconfig` (
  `confignum` int(11) NOT NULL DEFAULT '1',
  `version` varchar(5) NOT NULL DEFAULT '',
  `sitename` varchar(255) NOT NULL DEFAULT 'Members Area',
  `siteemail` varchar(255) NOT NULL DEFAULT 'you@yoursite.com',
  `dateformat` varchar(6) NOT NULL DEFAULT 'DDMMYY',
  `logoutpage` varchar(255) NOT NULL DEFAULT 'http://www.yoursite.com/index.html',
  `siteloklocation` varchar(255) NOT NULL DEFAULT '',
  `siteloklocationurl` varchar(255) NOT NULL DEFAULT '',
  `emaillocation` varchar(255) NOT NULL DEFAULT '',
  `emailurl` varchar(255) NOT NULL DEFAULT '',
  `filelocation` mediumtext,
  `siteloklog` varchar(255) NOT NULL DEFAULT '',
  `logdetails` varchar(50) NOT NULL DEFAULT 'YYYYYYYYYYYYYYYY',
  `sitekey` varchar(50) NOT NULL DEFAULT '',
  `logintype` varchar(10) NOT NULL DEFAULT 'NORMAL',
  `turinglogin` int(11) NOT NULL DEFAULT '0',
  `turingregister` int(11) NOT NULL DEFAULT '0',
  `maxsessiontime` int(11) NOT NULL DEFAULT '0',
  `maxinactivitytime` int(11) NOT NULL DEFAULT '0',
  `cookielogin` int(11) NOT NULL DEFAULT '0',
  `logintemplate` varchar(255) NOT NULL DEFAULT '',
  `expiredpage` varchar(255) NOT NULL DEFAULT '',
  `wronggrouppage` varchar(255) NOT NULL DEFAULT '',
  `messagetemplate` varchar(255) NOT NULL DEFAULT '',
  `forgottenemail` varchar(255) NOT NULL DEFAULT '',
  `newuseremail` varchar(255) NOT NULL DEFAULT 'newuser.htm',
  `showrows` int(11) NOT NULL DEFAULT '10',
  `actionitems` int(11) NOT NULL DEFAULT '1',
  `randompasswordmask` varchar(50) NOT NULL DEFAULT 'cccc##',
  `md5passwords` int(11) NOT NULL DEFAULT '0',
  `concurrentlogin` int(11) NOT NULL DEFAULT '1',
  `logviewoffset` int(11) NOT NULL DEFAULT '0',
  `logvieworder` varchar(4) NOT NULL DEFAULT 'ASC',
  `logviewdetails` varchar(50) NOT NULL DEFAULT 'YYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYY',
  `sortfield` varchar(100) NOT NULL DEFAULT '',
  `sortdirection` varchar(4) NOT NULL DEFAULT '',
  `customtitle1` varchar(255) NOT NULL DEFAULT 'Custom1',
  `customtitle2` varchar(255) NOT NULL DEFAULT 'Custom2',
  `customtitle3` varchar(255) NOT NULL DEFAULT 'Custom3',
  `customtitle4` varchar(255) NOT NULL DEFAULT '',
  `customtitle5` varchar(255) NOT NULL DEFAULT '',
  `customtitle6` varchar(255) NOT NULL DEFAULT '',
  `customtitle7` varchar(255) NOT NULL DEFAULT '',
  `customtitle8` varchar(255) NOT NULL DEFAULT '',
  `customtitle9` varchar(255) NOT NULL DEFAULT '',
  `customtitle10` varchar(255) NOT NULL DEFAULT '',
  `customtitle11` varchar(255) NOT NULL DEFAULT '',
  `customtitle12` varchar(255) NOT NULL DEFAULT '',
  `customtitle13` varchar(255) NOT NULL DEFAULT '',
  `customtitle14` varchar(255) NOT NULL DEFAULT '',
  `customtitle15` varchar(255) NOT NULL DEFAULT '',
  `customtitle16` varchar(255) NOT NULL DEFAULT '',
  `customtitle17` varchar(255) NOT NULL DEFAULT '',
  `customtitle18` varchar(255) NOT NULL DEFAULT '',
  `customtitle19` varchar(255) NOT NULL DEFAULT '',
  `customtitle20` varchar(255) NOT NULL DEFAULT '',
  `customtitle21` varchar(255) NOT NULL DEFAULT '',
  `customtitle22` varchar(255) NOT NULL DEFAULT '',
  `customtitle23` varchar(255) NOT NULL DEFAULT '',
  `customtitle24` varchar(255) NOT NULL DEFAULT '',
  `customtitle25` varchar(255) NOT NULL DEFAULT '',
  `customtitle26` varchar(255) NOT NULL DEFAULT '',
  `customtitle27` varchar(255) NOT NULL DEFAULT '',
  `customtitle28` varchar(255) NOT NULL DEFAULT '',
  `customtitle29` varchar(255) NOT NULL DEFAULT '',
  `customtitle30` varchar(255) NOT NULL DEFAULT '',
  `customtitle31` varchar(255) NOT NULL DEFAULT '',
  `customtitle32` varchar(255) NOT NULL DEFAULT '',
  `customtitle33` varchar(255) NOT NULL DEFAULT '',
  `customtitle34` varchar(255) NOT NULL DEFAULT '',
  `customtitle35` varchar(255) NOT NULL DEFAULT '',
  `customtitle36` varchar(255) NOT NULL DEFAULT '',
  `customtitle37` varchar(255) NOT NULL DEFAULT '',
  `customtitle38` varchar(255) NOT NULL DEFAULT '',
  `customtitle39` varchar(255) NOT NULL DEFAULT '',
  `customtitle40` varchar(255) NOT NULL DEFAULT '',
  `customtitle41` varchar(255) NOT NULL DEFAULT '',
  `customtitle42` varchar(255) NOT NULL DEFAULT '',
  `customtitle43` varchar(255) NOT NULL DEFAULT '',
  `customtitle44` varchar(255) NOT NULL DEFAULT '',
  `customtitle45` varchar(255) NOT NULL DEFAULT '',
  `customtitle46` varchar(255) NOT NULL DEFAULT '',
  `customtitle47` varchar(255) NOT NULL DEFAULT '',
  `customtitle48` varchar(255) NOT NULL DEFAULT '',
  `customtitle49` varchar(255) NOT NULL DEFAULT '',
  `customtitle50` varchar(255) NOT NULL DEFAULT '',
  `custom1validate` int(11) NOT NULL DEFAULT '0',
  `custom2validate` int(11) NOT NULL DEFAULT '0',
  `custom3validate` int(11) NOT NULL DEFAULT '0',
  `custom4validate` int(11) NOT NULL DEFAULT '0',
  `custom5validate` int(11) NOT NULL DEFAULT '0',
  `custom6validate` int(11) NOT NULL DEFAULT '0',
  `custom7validate` int(11) NOT NULL DEFAULT '0',
  `custom8validate` int(11) NOT NULL DEFAULT '0',
  `custom9validate` int(11) NOT NULL DEFAULT '0',
  `custom10validate` int(11) NOT NULL DEFAULT '0',
  `custom11validate` int(11) NOT NULL DEFAULT '0',
  `custom12validate` int(11) NOT NULL DEFAULT '0',
  `custom13validate` int(11) NOT NULL DEFAULT '0',
  `custom14validate` int(11) NOT NULL DEFAULT '0',
  `custom15validate` int(11) NOT NULL DEFAULT '0',
  `custom16validate` int(11) NOT NULL DEFAULT '0',
  `custom17validate` int(11) NOT NULL DEFAULT '0',
  `custom18validate` int(11) NOT NULL DEFAULT '0',
  `custom19validate` int(11) NOT NULL DEFAULT '0',
  `custom20validate` int(11) NOT NULL DEFAULT '0',
  `custom21validate` int(11) NOT NULL DEFAULT '0',
  `custom22validate` int(11) NOT NULL DEFAULT '0',
  `custom23validate` int(11) NOT NULL DEFAULT '0',
  `custom24validate` int(11) NOT NULL DEFAULT '0',
  `custom25validate` int(11) NOT NULL DEFAULT '0',
  `custom26validate` int(11) NOT NULL DEFAULT '0',
  `custom27validate` int(11) NOT NULL DEFAULT '0',
  `custom28validate` int(11) NOT NULL DEFAULT '0',
  `custom29validate` int(11) NOT NULL DEFAULT '0',
  `custom30validate` int(11) NOT NULL DEFAULT '0',
  `custom31validate` int(11) NOT NULL DEFAULT '0',
  `custom32validate` int(11) NOT NULL DEFAULT '0',
  `custom33validate` int(11) NOT NULL DEFAULT '0',
  `custom34validate` int(11) NOT NULL DEFAULT '0',
  `custom35validate` int(11) NOT NULL DEFAULT '0',
  `custom36validate` int(11) NOT NULL DEFAULT '0',
  `custom37validate` int(11) NOT NULL DEFAULT '0',
  `custom38validate` int(11) NOT NULL DEFAULT '0',
  `custom39validate` int(11) NOT NULL DEFAULT '0',
  `custom40validate` int(11) NOT NULL DEFAULT '0',
  `custom41validate` int(11) NOT NULL DEFAULT '0',
  `custom42validate` int(11) NOT NULL DEFAULT '0',
  `custom43validate` int(11) NOT NULL DEFAULT '0',
  `custom44validate` int(11) NOT NULL DEFAULT '0',
  `custom45validate` int(11) NOT NULL DEFAULT '0',
  `custom46validate` int(11) NOT NULL DEFAULT '0',
  `custom47validate` int(11) NOT NULL DEFAULT '0',
  `custom48validate` int(11) NOT NULL DEFAULT '0',
  `custom49validate` int(11) NOT NULL DEFAULT '0',
  `custom50validate` int(11) NOT NULL DEFAULT '0',
  `emailtype` int(11) NOT NULL DEFAULT '0',
  `emailusername` varchar(255) NOT NULL DEFAULT '',
  `emailpassword` varchar(255) NOT NULL DEFAULT '',
  `emailserver` varchar(255) NOT NULL DEFAULT '',
  `emailport` varchar(6) NOT NULL DEFAULT '25',
  `emailauth` int(11) NOT NULL DEFAULT '1',
  `emailserversecurity` varchar(6) NOT NULL DEFAULT '',
  `emaildelay` int(11) NOT NULL DEFAULT '0',
  `modifyuseremail` varchar(255) NOT NULL DEFAULT 'updateuser.htm',
  `noaccesspage` varchar(255) NOT NULL DEFAULT '',
  `dbupdate` int(11) NOT NULL DEFAULT '0',
  `siteemail2` varchar(255) NOT NULL DEFAULT '',
  `allowsearchengine` int(11) NOT NULL DEFAULT '0',
  `searchenginegroup` varchar(255) NOT NULL DEFAULT 'ALL',
  `profilepassrequired` int(11) NOT NULL DEFAULT '0',
  `emailconfirmrequired` int(11) NOT NULL DEFAULT '0',
  `emailconfirmtemplate` varchar(255) NOT NULL DEFAULT '',
  `emailunique` int(11) NOT NULL DEFAULT '0',
  `loginwithemail` int(11) NOT NULL DEFAULT '0',
  `columnorder` varchar(120) NOT NULL DEFAULT '',
  `backuplocation` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`confignum`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


INSERT INTO slconfig VALUES('1','4.0','NOMAS International','peterbe@verizon.net','DDMMYY','http://www.nomasinternational.org/feeding_forum.php','/home1/nomasint/public_html/_vibralogix/slpw/','http://www.nomasinternational.org/_vibralogix/slpw/','/home1/nomasint/public_html/_vibralogix/slpw/email/','http://www.nomasinternational.org/_vibralogix/slpw/email/','default=/home1/nomasint/public_html/_vibralogix/_files/slfiles_cvlcwl0d7aa/','','YYYYYYYYYYYYYYYY','xe9ykj76','NORMAL','0','0','0','0','0','','','','','','newuser.htm','50','1','cccc##','0','0','0','ASC','YYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYY','','','Custom 1','Custom 2','Custom 3','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','','','','','0','','250','updateuser.htm','','1','','0','','0','0','','0','0','ACSLCRUSPWENNMEMUG010203','/home1/nomasint/public_html/_vibralogix/_files/slbackups_d76swb8ar/');



DROP TABLE IF EXISTS log;


CREATE TABLE `log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `time` datetime NOT NULL,
  `username` varchar(50) NOT NULL DEFAULT '',
  `type` varchar(30) NOT NULL DEFAULT '',
  `details` varchar(255) NOT NULL DEFAULT '',
  `ip` varchar(46) NOT NULL DEFAULT '',
  `session` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;


INSERT INTO log VALUES('1','2013-07-19 13:34:01','admin','Login','','96.224.0.83','4640a5d3621d340b5941e925175110fbaa8c1a57');
INSERT INTO log VALUES('2','2013-07-19 13:39:54','admin','Logout','','96.224.0.83','4640a5d3621d340b5941e925175110fbaa8c1a57');
INSERT INTO log VALUES('3','2013-07-19 13:42:18','poeb','Login','','96.224.0.83','7d0bd9d9464df1be0fdf71cfabd2b48b0ebeb89a');
INSERT INTO log VALUES('4','2013-07-19 13:47:09','poeb','Logout','','96.224.0.83','7d0bd9d9464df1be0fdf71cfabd2b48b0ebeb89a');
INSERT INTO log VALUES('5','2013-07-19 14:21:47','poeb','Login','','96.224.0.83','c75d61ed6cc804332808a95f6334f3d85657c620');
INSERT INTO log VALUES('6','2013-07-19 14:22:16','poeb','Logout','','96.224.0.83','c75d61ed6cc804332808a95f6334f3d85657c620');
INSERT INTO log VALUES('7','2013-07-19 14:31:26','poeb','Login','','96.224.0.83','c0760a54157e95b30a75eeb39d187d55529c0d4f');
INSERT INTO log VALUES('8','2013-07-19 14:32:21','poeb','Logout','','96.224.0.83','c0760a54157e95b30a75eeb39d187d55529c0d4f');
INSERT INTO log VALUES('9','2013-07-19 14:32:29','poeb','Login','','96.224.0.83','62a32895ceb5ff9bf3f401fb44cb3d646888d1cb');
INSERT INTO log VALUES('10','2013-07-19 14:32:32','poeb','Logout','','96.224.0.83','62a32895ceb5ff9bf3f401fb44cb3d646888d1cb');
INSERT INTO log VALUES('11','2013-07-22 11:02:45','poeb','Login','','96.224.6.154','3cd7d9cd6861698785bc22222b9507647583a67c');
INSERT INTO log VALUES('12','2013-07-22 11:29:38','poeb','Logout','','96.224.6.154','3cd7d9cd6861698785bc22222b9507647583a67c');
INSERT INTO log VALUES('13','2013-08-03 13:58:40','poeb','Login','','96.232.17.167','fe00beebb7eedbff033cb192851d90439e68dd4e');



DROP TABLE IF EXISTS usergroups;


CREATE TABLE `usergroups` (
  `name` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL DEFAULT '',
  `loginaction` varchar(255) NOT NULL DEFAULT '',
  `loginvalue` varchar(255) NOT NULL DEFAULT '',
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;


INSERT INTO usergroups VALUES('ADMIN','Administrator','','','1');
INSERT INTO usergroups VALUES('ALL','All Areas','','','2');
INSERT INTO usergroups VALUES('FORUM','Feeding Forum Paid Member','URL','http://localhost/PUNKY-NEW/_mybb/','3');
INSERT INTO usergroups VALUES('NOMAS','NOMAS Licensee','','','5');



DROP TABLE IF EXISTS sl_ordercontrol;


CREATE TABLE `sl_ordercontrol` (
  `orderno` varchar(255) NOT NULL,
  `timest` int(11) NOT NULL DEFAULT '0',
  `status` varchar(255) NOT NULL DEFAULT '',
  `username` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`orderno`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;





DROP TABLE IF EXISTS sl_plugins;


;





# End of backup file
